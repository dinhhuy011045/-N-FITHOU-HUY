
package BAOCAOBAITAPLON;
import java.io.Serializable;
import java.util.Scanner;
public class CANBOTUYENSINH extends NGUOI implements Serializable{
private String macb,khoact;
public CANBOTUYENSINH() {}
public CANBOTUYENSINH(String macb, String khoact) {
	super();
	this.macb = macb;
	this.khoact = khoact;
}
public String getMacb() {
	return macb;
}
public void setMacb(String macb) {
	this.macb = macb;
}
public String getKhoact() {
	return khoact;
}
public void setKhoact(String khoact) {
	this.khoact = khoact;
}
@Override
public void nhap() {
	super.nhap();
	Scanner sc=new Scanner(System.in);
	System.out.println("nhap ma can bo :");
	macb=sc.nextLine();
	System.out.println("nhap khoa chuc truc thuoc :");
	khoact=sc.nextLine();	
}
@Override
public void xuat() {
	System.out.println("\t\t CAN BO TUYEN SINH ");
	super.xuat();
	System.out.println("-Ma can bo :"+macb+"  "+  "||\tKhoa truc thuoc "+khoact);	
}
@Override
public String toString() {
	return "CANBOTUYENSINH [macb=" + macb + ", khoact=" + khoact + "]";
}
}
