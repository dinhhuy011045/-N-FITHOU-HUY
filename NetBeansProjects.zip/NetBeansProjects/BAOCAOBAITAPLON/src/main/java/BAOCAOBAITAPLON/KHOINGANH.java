package BAOCAOBAITAPLON;
import java.io.Serializable;
import java.util.Scanner;
public class KHOINGANH implements Serializable {
private String macn,tencn,khoi;
public KHOINGANH() {}
public KHOINGANH(String macn, String tencn, String khoi) {	
	this.macn = macn;
	this.tencn = tencn;
	this.khoi = khoi;
}
public String getMacn() {
	return macn;
}
public void setMacn(String macn) {
	this.macn = macn;
}
public String getTencn() {
	return tencn;
}
public void setTencn(String tencn) {
	this.tencn = tencn;
}
public String getKhoi() {
	return khoi;
}
public void setKhoi(String khoi) {
	this.khoi = khoi;
}
public void nhap() {
	Scanner sc=new Scanner(System.in);
	System.out.println("nhap ma chuyen nganh :");
	macn=sc.nextLine();
	System.out.println("nhap ten chuyen nganh :");
	tencn=sc.nextLine();
	System.out.println("nhap khoi xet :");
	khoi=sc.nextLine();	
}
public void xuat() {
	System.out.println("-Ma chuyen nganh :"+macn+"  "+"||\tTen chuyen nganh :"+tencn);	
	System.out.println("-Khoi xet :"+khoi);
}
@Override
public String toString() {
	return "KHOINGANH [macn=" + macn + ", tencn=" + tencn + ", khoi=" + khoi + "]";
}
}
