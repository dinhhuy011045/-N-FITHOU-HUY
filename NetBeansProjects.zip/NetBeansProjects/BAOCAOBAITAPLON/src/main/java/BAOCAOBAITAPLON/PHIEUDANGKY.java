
package BAOCAOBAITAPLON;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

public class PHIEUDANGKY implements Serializable{
private String maphieu,ngaydk;
private int n;
THISINH tsinh=new THISINH();
CANBOTUYENSINH cb=new CANBOTUYENSINH();
private float diem1,diem2,diem3,diemuutien;
private ArrayList<KHOINGANH> dskhoinganh;
public PHIEUDANGKY() {
	this.dskhoinganh=new ArrayList<>();
}
public PHIEUDANGKY(String maphieu, String ngaydk, THISINH tsinh, CANBOTUYENSINH cb, float diem1, float diem2,
		float diem3, float diemuutien, ArrayList<KHOINGANH> dskhoinganh) {
	
	this.maphieu = maphieu;
	this.ngaydk = ngaydk;
	this.tsinh = tsinh;
	this.cb = cb;
	this.diem1 = diem1;
	this.diem2 = diem2;
	this.diem3 = diem3;
	this.diemuutien = diemuutien;
	this.dskhoinganh = dskhoinganh;
}
public void nhap() {
Scanner sc=new Scanner(System.in);
System.out.println("nhap ma phieu :");
maphieu=sc.nextLine();
System.out.println("nhap ngay dang ky :");
ngaydk=sc.nextLine();
System.out.println("\t\t NHAP THONG TIN THI SINH :\n");
tsinh.nhap();
System.out.println("\t\t NHAP THONG TIN CAN BO \n");
cb.nhap();
do {
System.out.println("nhap diem mon 1 :");
diem1=sc.nextFloat();
if(diem1<0) {
	System.out.println("Diem phai lon hon 0 ! Xin moi nhap lai !");
}
}while(diem1<0);
do {
System.out.println("nhap diem mon 2 :");
diem2=sc.nextFloat();
if(diem2<0) {
	System.out.println("Diem phai lon hon 0 ! Xin moi nhap lai !");
}
}
while(diem2<0);
do {
System.out.println("nhap diem mon 3 :");
diem3=sc.nextFloat();
if(diem3<0) {
	System.out.println("Diem phai lon hon 0 ! Xin moi nhap lai !");
}
}
while(diem3<0);
do {
System.out.println("nhap diem uu tien:");
diemuutien=sc.nextFloat();
if(diemuutien<0) {
	System.out.println("Diem phai lon hon 0 ! Xin moi nhap lai !!");
}}
while(diemuutien<0);
do {
System.out.println("\nNhap so khoi nganh \n");
n=sc.nextInt();
if(n<0) {
	System.out.println("so khoi nganh phai lon hon 0 ! xin moi nhap lai !");
	
}
}
while(n<0);

dskhoinganh =new ArrayList<>(n);
for(int i=0;i<n;i++) {
	System.out.println("\n\t\t NHAP KHOI NGANH THU "+(i+1)+"\n");
	KHOINGANH kn=new KHOINGANH();
	kn.nhap();
	dskhoinganh.add(kn);
}
}
public void xuat() {
	System.out.println("-Ma phieu :"+maphieu);
	System.out.println("-Ngay dang ky :"+ngaydk);
	tsinh.xuat();
	cb.xuat();
	System.out.println("-Diem mon 1 :"+diem1+"  "+"||\tDiem mon 2 :"+diem2+"  "+"||\tDiem mon 3 :"+diem3);
	System.out.println("-Diem uu tien :"+diemuutien);
	System.out.println("\n\t\t SO KHOI NGANH  "+n+"\n");
	int dem=0;
	for(KHOINGANH kn:dskhoinganh) {
		System.out.println("\n\t\t KHOI NGANH THU "+(dem+1)+"\n");
		kn.xuat();
	}
	
}
public float tinhdiem() {
	return diem1+diem2+diem3+diemuutien;
}
public String getMaphieu() {
	return maphieu;
}
public void setMaphieu(String maphieu) {
	this.maphieu = maphieu;
}
public String getNgaydk() {
	return ngaydk;
}
public void setNgaydk(String ngaydk) {
	this.ngaydk = ngaydk;
}
public int getN() {
	return n;
}
public void setN(int n) {
	this.n = n;
}
public THISINH getTsinh() {
	return tsinh;
}
public void setTsinh(THISINH tsinh) {
	this.tsinh = tsinh;
}
public CANBOTUYENSINH getCb() {
	return cb;
}
public void setCb(CANBOTUYENSINH cb) {
	this.cb = cb;
}
public float getDiem1() {
	return diem1;
}
public void setDiem1(float diem1) {
	this.diem1 = diem1;
}
public float getDiem2() {
	return diem2;
}
public void setDiem2(float diem2) {
	this.diem2 = diem2;
}
public float getDiem3() {
	return diem3;
}
public void setDiem3(float diem3) {
	this.diem3 = diem3;
}
public float getDiemuutien() {
	return diemuutien;
}
public void setDiemuutien(float diemuutien) {
	this.diemuutien = diemuutien;
}
public ArrayList<KHOINGANH> getDskhoinganh() {
	return dskhoinganh;
}
public void setDskhoinganh(ArrayList<KHOINGANH> dskhoinganh) {
	this.dskhoinganh = dskhoinganh;
}

public boolean  xettrungtuyen() {
	Scanner sc=new Scanner(System.in);
	float diemchuan;
	String manganh;
	boolean kiemtra=false;	
	System.out.println("nhap ten nganh can kiem tra :");
	manganh=sc.nextLine();
	do {
	System.out.println("Nhap diem chuan cua chuyen nganh :");
	diemchuan=sc.nextFloat();
	if(diemchuan<0) {
		System.out.println("Diem chuan phai lon hon 0 ! Xin moi nhap lai !");
	}
	}
	while(diemchuan<0);
	
for(KHOINGANH kn:dskhoinganh) {
	if(kn.getTencn().equals(manganh)==true) {
			if(tinhdiem()>=diemchuan) {
				kiemtra=true;
				break;
		}
	}
	}
   return kiemtra;
}
@Override
public String toString() {
	return "PHIEUDANGKY [maphieu=" + maphieu + ", ngaydk=" + ngaydk + ", n=" + n + ", tsinh=" + tsinh + ", cb=" + cb
			+ ", diem1=" + diem1 + ", diem2=" + diem2 + ", diem3=" + diem3 + ", diemuutien=" + diemuutien
			+ ", dskhoinganh=" + dskhoinganh + "]";
}

}
