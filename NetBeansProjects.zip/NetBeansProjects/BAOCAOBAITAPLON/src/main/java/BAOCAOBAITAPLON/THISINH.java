package BAOCAOBAITAPLON;
import java.io.Serializable;
import java.util.Scanner;
public class THISINH extends NGUOI implements Serializable{
private String ngaysinh,sodienthoai,email,socccd,mathisinh;
public THISINH() {}
public THISINH(String ngaysinh, String sodienthoai, String email, String socccd, String mathisinh) {
	super();
	this.ngaysinh = ngaysinh;
	this.sodienthoai = sodienthoai;
	this.email = email;
	this.socccd = socccd;
	this.mathisinh = mathisinh;
}

public String getNgaysinh() {
	return ngaysinh;
}
public void setNgaysinh(String ngaysinh) {
	this.ngaysinh = ngaysinh;
}
public String getSodienthoai() {
	return sodienthoai;
}
public void setSodienthoai(String sodienthoai) {
	this.sodienthoai = sodienthoai;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getSocccd() {
	return socccd;
}
public void setSocccd(String socccd) {
	this.socccd = socccd;
}
public String getMathisinh() {
	return mathisinh;
}
public void setMathisinh(String mathisinh) {
	this.mathisinh = mathisinh;
}
public void nhap()
{
	super.nhap();
	Scanner sc=new Scanner(System.in);
	System.out.println("nhap ngay sinh :");
	ngaysinh=sc.nextLine();
	System.out.println("nhap so dien thoai :");
	sodienthoai=sc.nextLine();
	System.out.println("nhap email :");
	email=sc.nextLine();
	System.out.println("nhap so cccd :");
	socccd=sc.nextLine();
	System.out.println("Ma thi sinh :");
        mathisinh=sc.nextLine();
}
public void xuat() {
        System.out.println("\n");
        System.out.println(" \n\t\t THONG TIN THI SINH");
	super.xuat();
	System.out.println("-Ma thi sinh :"+mathisinh+"  "+"||\tNgay sinh :"+ngaysinh);
	System.out.println("-So dien thoai :"+sodienthoai);
	System.out.println("-Email :"+email);
	System.out.println("-So cccd :"+socccd);
}
public String toString() {
	return "THISINH [ngaysinh=" + ngaysinh + ", sodienthoai=" + sodienthoai + ", email=" + email + ", socccd=" + socccd
			+ ", mathisinh=" + mathisinh + "]";
}
}
