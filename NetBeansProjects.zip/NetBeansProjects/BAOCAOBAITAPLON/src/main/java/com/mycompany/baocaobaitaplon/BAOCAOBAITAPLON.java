
package com.mycompany.baocaobaitaplon;

/**
 *
 * @author ad
 */
public class BAOCAOBAITAPLON {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
