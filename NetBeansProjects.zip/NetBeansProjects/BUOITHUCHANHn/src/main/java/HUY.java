
/**
 *
 * @author ad
 */
public class HUY {
    public static void main(String[] args) {
        System.out.println("NGUYEN DINH HUY");
    }
}
