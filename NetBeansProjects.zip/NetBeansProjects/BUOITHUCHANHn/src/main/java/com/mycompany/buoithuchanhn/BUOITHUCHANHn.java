
package com.mycompany.buoithuchanhn;

/**
 *
 * @author ad
 */
public class BUOITHUCHANHn {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
