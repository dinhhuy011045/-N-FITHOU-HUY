/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI04TH;
import java.util.Scanner;
public class QuanLySinhVien {
public static void main(String [] args ) {
	 int n;
	 double s=0;
         
	 SINHVIEN[] hocsinh;
	  Scanner sc=new Scanner(System.in);
		System.out.print("nhap so luong hoc sinh :");
		 n=sc.nextInt();
		 hocsinh=new SINHVIEN[n];
		
	 for(int i=0;i<n;i++) {
		hocsinh[i]=new SINHVIEN();
		hocsinh[i].nhap();
	 } 
	System.out.print("danh sach vua nhap la :\n\n");
	 for(int i=0;i<n;i++) {
		 hocsinh[i].hien();
		
	 }
	 for(int i=0;i<n;i++) {
		 s+=hocsinh[i].tongtien();
	 }
	 System.out.print("tong tien an ban chu la :"+s+"\n");
	 System.out.println("DANH SACH SAU KHI SAP XEP :\n");
	for(int i=0;i<n-1;i++) {
	 for(int j=i+1;j<n;j++) {
		 if(hocsinh[i].tongtien()>hocsinh[j].tongtien()) {
                 SINHVIEN tam=hocsinh[i];
                 hocsinh[i]=hocsinh[j];
                 hocsinh[j]=tam;
    
		 }
	    }
	 }
	
	 for(int i=0;i<n;i++) {
		 hocsinh[i].hien();
		
	 }
    	 
	System.out.println("\n");
	int dem=0;
	 System.out.print("cac hoc sinh co so buoi an ban chu tren 20 buoi la :\n");
		for(int i=0;i<n;i++) {
		if(hocsinh[i].getSobuoian()>20) {
			 hocsinh[i].hien();
		dem++;
		} 
		
		}
	 
	 if(dem==0) {
		 System.out.println("\nkhong co hoc sinh nao an ban chu tren 20 buoi :");
         }
    }
}
