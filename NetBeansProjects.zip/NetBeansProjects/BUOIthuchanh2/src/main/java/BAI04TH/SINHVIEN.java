/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI04TH;
import java.util.Scanner;
public class SINHVIEN {
	
	private String mahs;
	private String hoten;
	private String lop;
	private int sobuoian;
	
	public void nhap() {
		Scanner sc=new Scanner(System.in);
		
		 System.out.print("nhap ma hoc sinh :");
		 mahs=sc.nextLine();
		 System.out.print("nhap ho ten :");
		 hoten=sc.nextLine();
		 System.out.print("nhap lop :");
		 lop=sc.nextLine();
		 System.out.print("nhap so buoi an :\n");
		 sobuoian=sc.nextInt();
	}
	
	public String getMahs() {
		return mahs;
	}
	public void setMahs(String mahs) {
		this.mahs = mahs;
	}
	public String getHoten() {
		return hoten;
	}
	public void setHoten(String hoten) {
		this.hoten = hoten;
	}
	public String getLop() {
		return lop;
	}
	public void setLop(String lop) {
		this.lop = lop;
	}
	public int getSobuoian() {
		return sobuoian;
	}
	public void setSobuoian(int sobuoian) {
		this.sobuoian = sobuoian;
	}
	public void hien() {
		System.out.println(mahs+"  "+hoten+"  "+lop+"  "+sobuoian);
		System.out.println("\n");
	}
	public double tongtien() {
		return sobuoian*30000;
	}	
}