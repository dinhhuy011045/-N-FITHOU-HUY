/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI05TH;
import java.util.Scanner;
public class HCN {
    private int d;
    private int r;
public void nhap(){
    Scanner sc = new Scanner(System.in);
    do{
    do{
    System.out.println("NHAP CHIEU DAI:");
    d = sc.nextInt();
    }
    while(d<=0);
    do{
    System.out.println("NHAP CHIEU RONG:");
    r = sc.nextInt();
    }
    while(r<=0);
}
    while(d<r);
    
}
public int hien(){
    System.out.println("DIEN TICH HCN="+DienTich());
    System.out.println("CHU VI HCN="+ChuVi());
    return 0;
}
public float DienTich()
    {
        return d*r;
    }
public float ChuVi()
    {
        return (d+r)*2;
    }
public String toString(int cc ){
         return "("+d+","+r+","+DienTich()+","+ChuVi()+")";
}
public  void setd(int d){
        this.d = d;
}
public  void setr(int r){
        this.r = r;
}
public  int getd(){
        return d;
}
public int getr(){
        return r;
}
}