/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI05TH;
public class HCNTest {
    public static void main(String[] args) {
        HCN hcn=new HCN();
        hcn.nhap();
        hcn.hien();
        System.out.println(" HCN:"+ hcn.toString(0));
            }
        }