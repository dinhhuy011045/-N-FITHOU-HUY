/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI06TH;
import java.util.Scanner;
public class Congnhan {
    static float lcb;
    private float hsl;
    private String hoten;
public void nhap(){
    Scanner sc = new Scanner(System.in);
    System.out.println("-------------------------");
    System.out.println("NHAP HO TEN:");
    hoten=sc.nextLine();
    System.out.println("NHAP HSL:");
    hsl=sc.nextFloat();
}
public void sethoten(String cc){
    this.hoten=hoten;
}
public String gethoten(){
    return hoten;
}
public void sethsl(float cc){
    this.hsl=hsl;
}
public float gethsl(){
    return hsl;
}
public float tinhLuong(){
    return lcb*hsl;
}
public void hien(){
    System.out.println(hsl+"  "+hoten+"  "+tinhLuong());
    System.out.println("\n");
}
}
 
