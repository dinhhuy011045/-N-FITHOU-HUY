/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI06TH;
import java.util.Scanner;
public class QuanLyCongNhan {
      int n;
      float S;
    Congnhan dsCongnhan[];
    public void nhapdscn(){
      Scanner sc = new Scanner(System.in);
        do { 
        System.out.println("NHAP DANH SACH SO CONG NHAN:");
        n=sc.nextInt();
        if(n<=0||n>=20) {
			System.out.println("NHAP SAI ,VUI LONG NHAP LAI!!!");
        }
        }
        while (n<=0||n>=20);
        dsCongnhan=new Congnhan[n];

    
            for (int i = 0; i < n;  i++) {
               dsCongnhan[i]= new Congnhan();
               dsCongnhan[i].nhap();
            }
}
    public void hiendscn(){
        for (int i = 0; i < n ; i++){
               dsCongnhan[i].hien();}
            }
    public void soluonglonhonS(){
        Scanner sc = new Scanner(System.in);
        System.out.println("NHAP LUONG S:");
        S=sc.nextFloat();
        System.out.println(" DANH SACH CONG NHAN CO LUONG LON HON "+S+" LA:");
        for (int i = 0; i < n; i++) {
            if(dsCongnhan[i].tinhLuong()>S)
            {
                dsCongnhan[i].hien();
            } 
        }
}
}


