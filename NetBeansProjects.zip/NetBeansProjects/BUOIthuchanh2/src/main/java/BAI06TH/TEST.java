/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI06TH;
import java.util.Scanner;
public class TEST {
    public static void menu(){
        System.out.println("DANH SACH QUAN LY CONG NHAN:");
        System.out.println("1.NHAP DANH SACH CONG NHAN");
        System.out.println("2.HIEN DANH SACH CONG NHAN");
        System.out.println("3.HIEN DANH SACH CONG NHAN LUONG > S");
        System.out.println("0.DUNG CHUONG TRINH");
    }
    public static void main(String[] args) {
        QuanLyCongNhan cn = new QuanLyCongNhan();
        int chon;
        Congnhan.lcb=1150;
        Scanner sc = new Scanner(System.in);
        do { 
        menu();
            System.out.println("MOI BAN CHON:");
            chon = sc.nextInt();
        switch(chon){
            case 1 -> cn.nhapdscn();
            case 2 -> cn.hiendscn();
            case 3 -> cn.soluonglonhonS();
            case 0 -> System.exit(chon);         
        }          
        } while (chon!=0);
        
    }
    
}
