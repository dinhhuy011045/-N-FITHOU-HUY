/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI07TH;
import java.util.Scanner;
import java.lang.Math;
public class diem {
	protected float x;
	protected float y;

    public float getX() {
        return x;
    }

    public void setX(float x) {
        this.x = x;
    }

    public float getY() {
        return y;
    }

    public void setY(float y) {
        this.y = y;
    }
	
	
	public void nhap() {
		Scanner sc=new Scanner(System.in);
		System.out.println("nhap toa do x: ");
		x=sc.nextFloat();
		System.out.println("nhap toa do y: ");
		y=sc.nextFloat();
	}
	@Override
	public String toString() {
		return "(" + x + "," + y +")";
	}
}

