/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI07TH;
import java.util.Scanner;
public class doanthang {
	private float diemdau;
	private float diemcuoi;
	public float getDiemdau() {
		return diemdau;
	}
	public void setDiemdau(float diemdau) {
		this.diemdau = diemdau;
	}
	public float getDiemcuoi() {
		return diemcuoi;
	}
	public void setDiemcuoi(float diemcuoi) {
		this.diemcuoi = diemcuoi;
	}
	public double tinhkhoangcach(diem A,diem B) {
		return Math.sqrt((B.x-A.x)*(B.x-A.x)+(B.y-A.y)*(B.y-A.y));
	}
	
	public void nhap(diem A[],diem B[],int n) {
		doanthang dt=new doanthang();
		double m[]=new double[n];
		for(int i=0;i<n;i++) {
			A[i]=new diem();
			B[i]=new diem();
			System.out.println("nhap toa do diem dau: ");
			A[i].nhap();
			System.out.println("nhap toa do diem cuoi: ");
			B[i].nhap();
		}
	}
        public void hien(diem A[], diem B[],int n) {
		System.out.println("thong tin cac doan thang la: ");
		for(int i=0;i<n;i++) {
			System.out.println("thong tin doan thang thu "+(i+1)+": ");
			System.out.println("toa do diem dau la: "+A[i]);
			System.out.println("toa do diem cuoi la: "+B[i]);
			System.out.println("\n");
		}
	}
	public void timdoanthangdainhat(diem A[],diem B[],int n,double m[]) {
		double max=m[0];
		double c=0,d=0;
		for(int i=0;i<n;i++) {
			if(max<m[i]) {
				c=max;
				max=m[i];
				m[i]=c;
				d=i;
			}
		}
		System.out.println("thong tin doan thang co do dai lon nhat la: ");
		System.out.println("toa do diem dau la: "+A[(int)d]);
		System.out.println("toa do diem cuoi la: "+B[(int)d]);
		System.out.println(" ");
	}
	public void tingtongdodaicacdoanthang(int n,double m[]) {
		double tong=0;
		for(int i=0;i<n;i++) {
			tong+=m[i];
		}
		System.out.println("tong do dai cac doan thang da nhap la: "+tong);
	}	
}  

