/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI07TH;
import java.util.Scanner;
public class test {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("nhap so doan thang: ");
		int n=sc.nextInt();
		doanthang dt=new doanthang();
		double m[]=new double[n];
		diem A[]=new diem[n];
		diem B[]=new diem[n];
		dt.nhap(A,B,n);
		for(int i=0;i<n;i++) {
			m[i]=dt.tinhkhoangcach(A[i],B[i]);
		}
		dt.hien(A,B,n);
		dt.timdoanthangdainhat(A,B,n,m);
		dt.tingtongdodaicacdoanthang(n,m);
	}
}

