/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI09TH;
import java.util.Scanner;
public class Congnhan {
    static float lcb;
    private float hsl;
    private String hoten;
public void nhap(){
    Scanner sc = new Scanner(System.in);
    System.out.println("-------------------------");
    System.out.println("NHAP HO TEN:");
    hoten=sc.nextLine();
    System.out.println("NHAP HSL:");
    hsl=sc.nextFloat();
}
public void sethoten(String cc){
    this.hoten=hoten;
}
public String gethoten(){
    return hoten;
}
public void sethsl(float cc){
    this.hsl=hsl;
}
public float gethsl(){
    return hsl;
}
public void hien(float pc){
    System.out.println("HO TEN:"+hoten);
    System.out.println("HE SO LUONG:"+hsl);
    System.out.println("LUONG T:"+lcb*hsl);
    System.out.println("LUONG S:"+lcb*hsl*(1+pc));
}
public double a(float pc){
     return (lcb*hsl*(1+pc))-(lcb*hsl);
}
}
 

    

