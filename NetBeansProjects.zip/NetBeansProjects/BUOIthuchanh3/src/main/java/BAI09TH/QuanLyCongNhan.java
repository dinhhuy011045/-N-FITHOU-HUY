/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI09TH;
import java.util.Scanner;
public class QuanLyCongNhan {
    public static void main(String[] args) {
      int n;
      float pc=0;
      double s=0;
      Congnhan dsCongnhan[];
      Scanner sc = new Scanner(System.in);
        Congnhan.lcb=1150;
        do { 
        System.out.println("NHAP DANH SACH SO CONG NHAN:");
        n=sc.nextInt();
        if(n<=0||n>20) {
			System.out.println("NHAP SAI ,VUI LONG NHAP LAI DUNG DE BAI!!!");
        }}
        while (n<=0||n>20);
        dsCongnhan=new Congnhan[n];
            for (int i = 0; i < n;  i++) {
               dsCongnhan[i]= new Congnhan();
               dsCongnhan[i].nhap(); 
                System.out.println("NHAP MUC PHU CAP");
                pc=sc.nextFloat();
}  
        for (int i = 0; i < n ; i++){
            System.out.println("===========================");
               System.out.println("THONG TIN CONG NHAN THU"+(i+1)+" "+"LA:");
               dsCongnhan[i].hien(pc);}        
        for(int i=0;i<n;i++){
            s+=dsCongnhan[i].a(pc);
        }
        System.out.println("TONG SO TIEN SAU KHI CHI TRA PHU CAP LA:"+s);
        
    }}
            

        
        
        
