/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI011TH;
public class Customer extends Person {
	private String tenCongTy;
	private double giaTriHoaDon;

	public Customer(String hoTen, String diaDiem, String tenCongTy, double giaTriHoaDon) {
		super(hoTen, diaDiem);
		this.tenCongTy = tenCongTy;
		this.giaTriHoaDon = giaTriHoaDon;
	}

	public String getTenCongTy() {
		return tenCongTy;
	}

	public double getGiaTriHoaDon() {
		return giaTriHoaDon;
	}

	@Override
	public String getInfor() {
		return "Customer [tenCongTy=" + tenCongTy + ", giaTriHoaDon=" + giaTriHoaDon + "]" + super.getInfor();
	}

	public String danhGia() {
		if (giaTriHoaDon > 200000) {
			return "ĐU";
		} else {
			return "THIEU";
		}
	}

	public void xuatThongTin() {
		super.xuatThongTin();
		System.out.printf("%10s%10.2f%10s\n", tenCongTy, giaTriHoaDon, danhGia());
	}
}
