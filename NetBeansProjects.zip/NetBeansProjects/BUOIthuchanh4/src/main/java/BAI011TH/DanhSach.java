/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI011TH;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
public class DanhSach {
	static Scanner sc = new Scanner(System.in);
	ArrayList<Person> listPerson = new ArrayList<>();
	private int soLuong;

	public Person nhapStudent() {
		System.out.print("NHAP HO TEN HOC SINH: ");
		String hoTen = sc.nextLine();
		System.out.print("NHAP DIA CHI: ");
		String diaChi = sc.nextLine();
		System.out.print("NHAP DIEM MON 1: ");
		double diemMon1 = sc.nextDouble();
		System.out.print("NHAP DIEM MON 2: ");
		double diemMon2 = sc.nextDouble();
		sc.nextLine();
		return new Student(hoTen, diaChi, diemMon1, diemMon2);
	}

	public Person nhapEmployee() {
		System.out.print("NHAP HO TEN NHAN VIEN: ");
		String hoTen = sc.nextLine();
		System.out.print("NHAP DIA CHI: ");
		String diaChi = sc.nextLine();
		System.out.print("NHAP HE SO LUONG: ");
		double hsl = sc.nextDouble();
		sc.nextLine();
		return new Employee(hoTen, diaChi, hsl);
	}

	public Person nhapCustomer() {
		System.out.print("NHAP HO TEN KHACH HANG: ");
		String hoTen = sc.nextLine();
		System.out.print("NHAP DIA CHI: ");
		String diaChi = sc.nextLine();
		System.out.print("NHAP TEN CONG TY: ");
		String tenCongTy = sc.nextLine();
		System.out.print("NHAP GIA TRI HANG HOA: ");
		double giaTriHangHoa = sc.nextDouble();
		sc.nextLine();
		return new Customer(hoTen, diaChi, tenCongTy, giaTriHangHoa);
	}

    /**
     *
     */
    public void nhapDS() {
		int option;
		System.out.println("-------- CHON DOI TUONG THUC HIEN --------");
		System.out.println("1. HOC SINH");
		System.out.println("2. NHAN VIEN");
		System.out.println("3. KHACH HANG");
		System.out.println("0. EXIT");
		System.out.print("MOI BAN CHON: ");
		option = sc.nextInt();
		sc.nextLine();
		switch (option) {
		case 1:
			System.out.println("--------- THONG TIN SINH VIEN ---------");
			System.out.print("NHAP SO LUONG SINH VIEN: ");
			soLuong = sc.nextInt();
			sc.nextLine();
			for (int i = 0; i < soLuong; i++) {
				listPerson.add(nhapStudent());
			}
			break;

		case 2:
			System.out.println("--------- THONG TIN NHAN VIEN---------");
			System.out.print("NHAP SO LUONG NHAN VIEN: ");
			soLuong = sc.nextInt();
			sc.nextLine();
			for (int i = 0; i < soLuong; i++) {
				listPerson.add(nhapEmployee());
			}
			break;

		case 3:
			System.out.println("--------- THONG TIN KHACH HANG ---------");
			System.out.print("NHAP SO LUONG KHACH HANG: ");
			soLuong = sc.nextInt();
			sc.nextLine();
			for (int i = 0; i < soLuong; i++) {
				listPerson.add(nhapCustomer());
			}
			break;
		}
	}

	public void xuatDS() {
		System.out.println("--------- THONG TIN DA NHAP ---------");
		for (int i = 0; i < listPerson.size(); i++) {
			System.out.print((i + 1) + ": ");
			listPerson.get(i).xuatThongTin();
		}
	}

	public void xoaNguoi() {
		System.out.print("NHAP HO TEN NGUOI CAN XOA: ");
		String hoTen = sc.nextLine();
		for (int i = 0; i < listPerson.size(); i++) {
			if (listPerson.get(i).getHoTen().equalsIgnoreCase(hoTen)) {
				listPerson.remove(i);
				xuatDS();
			}
		}
	}

	public void sapXepTheoHoTen() {
		Collections.sort(listPerson, new Comparator<Person>() {
			@Override
			public int compare(Person o1, Person o2) {
				return o1.getHoTen().compareTo(o2.getHoTen());
			}

		});
		xuatDS();
	}

    
}