/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI011TH;
public class Employee extends Person {
	private double hsl;

	public Employee(String hoTen, String diaDiem, double hsl) {
		super(hoTen, diaDiem);
		this.hsl = hsl;
	}

	public double getHsl() {
		return hsl;
	}

	@Override
	public String getInfor() {
		return "Employee [hsl=" + hsl + "]" + super.getInfor();
	}

	public String danhGia() {
		if (hsl > 2.0) {
			return "CAO";
		} else {
			return "THAP";
		}
	}

	public void xuatThongTin() {
		super.xuatThongTin();
		System.out.printf("%10f,2%10s\n", hsl, danhGia());
	}
}
