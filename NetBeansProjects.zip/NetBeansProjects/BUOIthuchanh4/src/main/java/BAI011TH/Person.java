/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI011TH;
public class Person {
	protected String hoTen, diaDiem;

	public Person(String hoTen, String diaDiem) {
		this.hoTen = hoTen;
		this.diaDiem = diaDiem;
	}

	public Person() {
		
	}

	public String getHoTen() {
		return hoTen;
	}

	public String getDiaDiem() {
		return diaDiem;
	}

	@Override
	public String toString() {
		return "Person [hoTen:" + hoTen + ", diaDiem:" + diaDiem + "]";
	}

	public void xuatThongTin() {
		System.out.printf("%s%15s",hoTen,diaDiem);
	}

	public String getInfor() {		
		return null;
	}


}
