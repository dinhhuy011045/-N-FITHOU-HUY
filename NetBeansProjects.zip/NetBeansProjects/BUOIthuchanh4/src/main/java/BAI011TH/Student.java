/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI011TH;
public class Student extends Person {
	private double diemMon1, diemMon2;

	public Student(String hoTen, String diaDiem, double diemMon1, double diemMon2) {
		super(hoTen, diaDiem);
		this.diemMon1 = diemMon1;
		this.diemMon2 = diemMon2;
	}

	public double getDiemMon1() {
		return diemMon1;
	}

	public double getDiemMon2() {
		return diemMon2;
	}

	public double diemTBC() {
		return (diemMon1 + diemMon2) / 2;
	}

	@Override
	public String toString() {
		return "Student [diemMon1:" + diemMon1 + ", diemMon2:" + diemMon2 + ", tbc:" + diemTBC() + "]";
	}

	public String danhGia() {
		if (diemTBC() > 8.0) {
			return "GIOI";
		} else if (diemTBC() < 8.0 && diemTBC() > 6.0) {
			return "KHA";
		} else {
			return "TRUNG BINH";
		}
	}

	public void xuatThongTin() {
		super.xuatThongTin();
		System.out.printf("%8.2f%8.2f%10.3f%15s\n", diemMon1, diemMon2, diemTBC(), danhGia());
	}
}
