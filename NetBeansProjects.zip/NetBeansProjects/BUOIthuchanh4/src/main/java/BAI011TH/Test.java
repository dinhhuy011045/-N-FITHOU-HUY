/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI011TH;
public class Test {
	public static void main(String[] args) {             
		DanhSach ds = new DanhSach();
		System.out.println("NHAP DANH SACH THONG TIN");
		ds.nhapDS();
		System.out.println("XUAT DANH SACH THONG TIN");
		ds.xuatDS();
		System.out.println("SAP XEP THEO HO TEN");
		ds.sapXepTheoHoTen();
		System.out.println("XOA THONG TIN");
		ds.xoaNguoi();

	}
}