/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI10TH;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
public class DSTULANH {
    ArrayList<TULANH> TL;
public void nhapdstl(){
    Scanner sc = new Scanner(System.in);
    int n;
    System.out.println("NHAP DANH SACH CAC TU LANH:");
    n=sc.nextInt();
    TL = new ArrayList<>(n);
    for (int i = 0; i < n; i++) {
        System.out.println("NHAP THONG TIN TU LANH THU"+" "+(i+1)+" ");
        TULANH tl = new TULANH();
        tl.nhap();
        TL.add(tl);  }  
    }
public void indstl(){
    int i=1;
		for(TULANH tl : TL) {
			System.out.println("\n\t\t THONG TIN PHIEU DANG KY THU "+(i++)+" LA :\n ");
			tl.hienThi();
                }}
public void lietKe() {
                Scanner sc = new Scanner(System.in);
		System.out.print("NHAP TEN HANG SAN XUAT CAN TIM: ");
		String hangCanTim = sc.nextLine();
                System.out.println("THONG TIN CUA HANG SAN XUAT CAN TIM LA:");
		for (TULANH tl : TL) {
			if (tl.getHangSX().equals(hangCanTim)) {
				tl.hienThi();
			} 
		}
	}
public void tinhTong(){
    double s =0;
    for (TULANH tl : TL){
        s+= tl.getDongia()*tl.getSoluong();}
        System.out.println("TONG TIEN DANH SACH CAC TU LANH LA:"+s);
    
}
    public void tldtlon200(){
        System.out.println("CAC TU LANH CO DUNG TICH TREN 200 LA:");
        
        for(TULANH tl : TL)
        if(tl.getDungTich()>200 ){
		        System.out.println("\n.===================================.");
			tl.hienThi();
            }         
         
    }
    public void sapXepgiamdan() {  
    System.out.println("DANH SACH TU LANH SAU KHI SAP XEP GIAM DAN THEO SO LUONG LA:");
    Collections.sort(TL, new SapxepGiamDan());
        for (TULANH tl : TL) {
            System.out.println("\n.===================================.");
            tl.hienThi();          
                }
	}
}  

	           
        
        
	


    
       

