/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI10TH;
import java.util.Scanner;
public class MAIN {
    public static void menu(){
    System.out.println("\n");
    System.out.println("""
                           +---------------------MENU---------------------+
                           |1.NHAP DANH DACH CAC TU LANH                  |
                           |2.IN DANH SACH CAC TU LANH                    |
                           |3.LIET KE DANH SACH TU LANH THEO HANG         |
                           |4.TONG TIEN CAC TU LANH                       |
                           |5.In cac tu lanh co dung tich tren 200 lit    |
                           |6.Sap xep theo thu tu giam dan cua so luong   |
                           |0.Exit                                        |
                           +----------------------------------------------+
                           """);  
        
    }     
    public static void main(String[] args) {
        DSTULANH dstl = new DSTULANH();
        Scanner sc = new Scanner(System.in);
        int chon;      
        do {  
        menu();
            System.out.println("MOI BAN CHON:");
            chon=sc.nextInt();
            switch (chon) {
                case 1:                   
                    dstl.nhapdstl();
                    break;
                case 2:
                    dstl.indstl();         
                    break;
                case 3:
                    dstl.lietKe();
                    break;
                case 4:
                    dstl.tinhTong();
                    break;
                case 5:
                    dstl.tldtlon200();
                    break;
                case 6:
                    dstl.sapXepgiamdan();
                    break;          
                case 0:
                    System.exit(chon);                    
                default:
                    System.out.println("NHAP SAI DE BAI HAY NHAP LAI!!!");
            }
            
        } while (chon!=0);
        
    }
}
    

