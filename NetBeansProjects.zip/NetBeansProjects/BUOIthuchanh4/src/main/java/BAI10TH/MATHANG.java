/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI10TH;
import java.util.Scanner;
public class MATHANG {
    private String tenHang;
    private String nuocSX;   
    private int maHang;
public MATHANG(){}
    public MATHANG(String tenHang, String nuocSX, int maHang) {
        this.tenHang = tenHang;
        this.nuocSX = nuocSX;
        this.maHang = maHang;
    }

public void nhap(){
    Scanner sc = new Scanner(System.in);
    System.out.println("NHAP TEN HANG:");
    tenHang=sc.nextLine();
    System.out.println("NHAP NUOC SAN XUAT:");
    nuocSX=sc.nextLine();
     System.out.println("NHAP MA HANG:");
    maHang=sc.nextInt();
}
public void hienThi(){
    System.out.print("\n.TEN HANG: "+tenHang);
    System.out.print("\n.MA HANG: "+maHang);
    System.out.print("\n.NUOC SAN XUAT: "+nuocSX);
}

        }
