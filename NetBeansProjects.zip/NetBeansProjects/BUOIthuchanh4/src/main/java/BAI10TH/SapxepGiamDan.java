/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI10TH;
import java.util.Comparator;
public class SapxepGiamDan implements Comparator<TULANH>{
    @Override
    public int compare(TULANH o1, TULANH o2) {
        return o2.getSoluong() - o1.getSoluong();
    }
}


