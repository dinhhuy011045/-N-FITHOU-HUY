/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI10TH;
import java.util.Scanner;
public class TULANH extends MATHANG{
    private String mauSac;  
    private String hangSX;  
    private int dungTich;
    private int soluong;
    private float dongia;
public TULANH(){}
    public TULANH(String mauSac, String hangSX, int dungTich, int soluong, float dongia) {
        this.mauSac = mauSac;
        this.hangSX = hangSX;
        this.dungTich = dungTich;
        this.soluong = soluong;
        this.dongia = dongia;
    }

    @Override
    public void nhap(){
    super.nhap();
    Scanner sc = new Scanner(System.in);
    System.out.println("NHAP MAU SAC:");
    mauSac=sc.nextLine();
    System.out.println("NHAP HANG SAN XUAT:");
    hangSX=sc.nextLine();
    System.out.println("NHAP DUNG TICH:");
    dungTich=sc.nextInt();
    System.out.println("NHAP SO LUONG:");
    soluong=sc.nextInt();
    System.out.println("NHAP DON GIA:");
    dongia=sc.nextFloat();
    
}
    @Override
    public void hienThi(){
    super.hienThi();
    System.out.print("\n.DUNG TICH: "+dungTich);
    System.out.print("\n.MAU SAC: "+mauSac);
    System.out.print("\n.HANG SAN XUAT: "+hangSX);
    System.out.print("\n.SO lUONG: "+soluong);
    System.out.print("\n.DON GIA: "+dongia);
    }

    public String getHangSX() {
        return hangSX;
    }

    public void setHangSX(String hangSX) {
        this.hangSX = hangSX;
    }

    public float getDongia() {
        return dongia;
    }

    public void setDongia(float dongia) {
        this.dongia = dongia;
    }

    public int getDungTich() {
        return dungTich;
    }

    public void setDungTich(int dungTich) {
        this.dungTich = dungTich;
    }

    public int getSoluong() {
        return soluong;
    }

    public void setSoluong(int soluong) {
        this.soluong = soluong;
    }

    
    
}
