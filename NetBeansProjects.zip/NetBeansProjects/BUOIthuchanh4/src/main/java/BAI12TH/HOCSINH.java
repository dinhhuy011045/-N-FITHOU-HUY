/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI12TH;
import java.util.Scanner;
public class HOCSINH extends NGUOI{
    private String Tenlop;  
    public void nhap() {
        super.Nhap(); 
    Scanner sc = new Scanner(System.in);
        System.out.println("NHAP TEN LOP:");
        Tenlop=sc.nextLine();
    }
    public void hien(){
        super.Hien();
        System.out.println("TEN LOP:"+Tenlop);
        System.out.println("\n");
    }
    public String getTenlop() {
        return Tenlop;
    }
    public void setTenlop(String Tenlop) {
        this.Tenlop = Tenlop;
    }
    
}