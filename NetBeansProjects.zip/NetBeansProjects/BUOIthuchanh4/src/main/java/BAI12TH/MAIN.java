/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI12TH;
import java.util.Scanner;
public class MAIN {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        HOCSINH hs [];
        System.out.println("NHAP DANH SACH SO HOC SINH:");
        n=sc.nextInt();     
        hs = new HOCSINH[n];
        for (int i = 0; i < n; i++) {
            hs[i]= new HOCSINH();
            System.out.println("===================");
            System.out.println("NHAP THONG TIN DSHS THU" +" "+(i+1)+":");
            hs[i].nhap();}
        System.out.println("DANH SACH HOC SINH CUA CAC LOP KHAC NHAU LA:");    
        for (int i = 0; i < n; i++){
            System.out.println("===================");
            hs[i].hien();
        }  
        System.out.println("================");
        System.out.println("DSHS SAU KHI DUOC SAP XEP THEO TEN LOP LA:");
        for (int i = 0; i < n-1; i++) {
            for (int j = i +1; j < n; j++) {
                if(hs[i].getTenlop().compareTo(hs[j].getTenlop())>0){
                    HOCSINH rem =hs[i];
                    hs[i]=hs[j];
                    hs[j]=rem;    
                }               
            } 
        }
        for (int i = 0; i < n; i++) {
           hs[i].hien(); 
        }
        System.out.println("END OF PROGRAMMING!!!");
    }   
}
