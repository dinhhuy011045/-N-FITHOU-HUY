/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI12TH;
import java.util.Scanner;
public class NGUOI {
    private String Hoten;
    private String Gioitinh;
public void Nhap(){
    Scanner SC =  new Scanner(System.in);
    System.out.println("NHAP HO TEN:");
    Hoten = SC.nextLine();
    System.out.println("NHAP GIOI TINH:");
    Gioitinh = SC.nextLine();
}   
public void Hien(){
    System.out.println("HO TEN:"+Hoten);
    System.out.println("GIOI TINH:"+Gioitinh);
}

}
