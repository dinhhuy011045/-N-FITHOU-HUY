/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI13TH;
import java.util.Scanner;

public class ChuyenVien extends CanBo implements Luong {           
    public String phong;   
    @Override
    public float TinhLuong() {
        return this.hsl * 1350000;
    }

    @Override
    public void nhap() {
        super.nhap(); 
        System.out.print("Nhap Phong: ");
        this.phong = new Scanner(System.in).nextLine();
    }

    @Override
    public void xuat() {
        System.out.println("Phong: "+this.phong);
        System.out.println("Luong: " + TinhLuong());
    }
}