/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI13TH;
import java.util.ArrayList;

public class DSNhanVien {
    ArrayList<CanBo> ds = new ArrayList<CanBo>();
    CanBo cb;
    public void nhapDs(int chon){
        switch (chon) {
        case 1:
            
            cb = new CanBo();
            cb.nhap();
            ds.add(cb);
            break;
        case 2:
            
            cb = new GiangVien();
            cb.nhap();
            ds.add(cb);
            break;
        case 3:
       
            cb = new QuanLy();
            cb.nhap();
            ds.add(cb);
            break;
        case 4:
            this.xuatDs();
            break;

        default:
            break;
        }
    }

    public void xuatDs(){
        for (CanBo canBo : ds) {
                canBo.xuat();
        }
    }

}