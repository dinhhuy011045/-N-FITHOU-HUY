/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI13TH;
import java.util.Scanner;
public class GiangVien extends CanBo implements Luong {

    private String khoa;

   
    @Override
    public float TinhLuong() {
        return  this.hsl * 1350000 * 0.2f;
    }

    @Override
    public void nhap() {
        super.nhap(); 
        System.out.print("Nhap khoa: ");
        this.khoa = new Scanner(System.in).nextLine();
    }

    @Override
    public void xuat() {
        super.xuat(); 
        System.out.println("Khoa:" + this.khoa);
        System.out.println("Luong: " + TinhLuong());
    }   
}