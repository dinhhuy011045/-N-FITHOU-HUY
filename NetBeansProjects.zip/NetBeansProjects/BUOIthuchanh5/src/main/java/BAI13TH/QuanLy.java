/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI13TH;
import java.util.Scanner;

public class QuanLy extends CanBo implements Luong {

    public float phuCap;
    public String phong;
    public String khoa;

    public void nhap() {
        
        super.nhap();
        System.out.print("Nhap Phong: ");
        this.phong =  new Scanner(System.in).nextLine();
        System.out.print("Nhap Khoa: ");
        this.khoa = new Scanner(System.in).nextLine();
        System.out.print("Nhap Phu Cap: ");
        this.phuCap = new Scanner(System.in).nextFloat();
    }
    public float TinhLuong() {
        return (this.hsl + this.phuCap) * 1350000;
    }

    @Override
    public void xuat() {
        super.xuat(); 
        System.out.println("Phu cap: "+this.phuCap);
        System.out.println("Phong: "+this.phong);
        System.out.println("Khoa: "+this.khoa);
        System.out.println("Luong: "+TinhLuong());
    }
}