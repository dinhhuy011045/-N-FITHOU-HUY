/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI13TH;
import java.util.Scanner;
public class Test {
    public static void menu(){
            
        System.out.println("=========MENU=========");
        System.out.println("1.Chuyen vien  ");
        System.out.println("2.Giang vien  ");
        System.out.println("3.Ten quan ly  ");
        System.out.println("4.Hien danh sach  ");
        System.out.println("0.Thoat.  ");
    }
    public static void main(String[] args) {
        DSNhanVien dsnv = new DSNhanVien();
        int chon;
        do {
                menu();
                System.out.print("Moi Ban Chon so: ");
                chon = new Scanner(System.in).nextInt();                        
                System.out.println("======================");
                dsnv.nhapDs(chon);
                
             
        } while (chon!=0);
    }
}