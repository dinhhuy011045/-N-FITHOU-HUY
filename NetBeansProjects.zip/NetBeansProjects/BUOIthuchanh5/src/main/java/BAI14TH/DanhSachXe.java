/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI14TH;
import java.util.ArrayList;
import java.util.Scanner;
public class DanhSachXe {
	ArrayList<PhuongTien> listPhuongTien = new ArrayList<>();

	public void nhapDs() {
		Scanner sc = new Scanner(System.in);
		int chon, soLuong;
		System.out.println("-------- Chon doi tuong thuc hien --------");
		System.out.println("1. Xe khach");
		System.out.println("2. Xe dap");
		System.out.println("3. Xe may");
		System.out.println("3. Xe o to khach");
		System.out.println("0. Thoat");
		System.out.print("Moi chon: ");
		chon = sc.nextInt();
		sc.nextLine();
		switch (chon) {
		case 1:
			System.out.printf("Nhap so luong xe khach: ");
			soLuong = sc.nextInt();
			for (int i = 0; i < soLuong; i++) {
				OtoKhach xk = new OtoKhach();
				xk.nhapOtoKhach();
				listPhuongTien.add(xk);
			}
			break;
		case 2:
			System.out.printf("Nhap so luong xe dap: ");
			soLuong = sc.nextInt();
			for (int i = 0; i < soLuong; i++) {
				XeDap xd = new XeDap();
				xd.nhapXeDap();;
				listPhuongTien.add(xd);
			}
			break;
		case 3:
			System.out.printf("Nhap so luong xe may: ");
			soLuong = sc.nextInt();
			for (int i = 0; i < soLuong; i++) {
				XeMay xm = new XeMay();
				xm.nhapXeMay();;
				listPhuongTien.add(xm);
			}
			break;
		case 4:
			System.out.printf("Nhap so luong xe o to tai: ");
			soLuong = sc.nextInt();
			for (int i = 0; i < soLuong; i++) {
				otoTai xt = new otoTai();
				xt.nhapXetai();
				listPhuongTien.add(xt);
			}
			break;
		default:
			throw new IllegalArgumentException("Unexpected value: " + chon);
		}
	}

	public void xuatDs() {
		for (int i = 0; i < listPhuongTien.size(); i++) {
			listPhuongTien.get(i).xuatThongTin();
		}
	}
}
