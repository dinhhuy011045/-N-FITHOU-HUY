/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI14TH;
import java.util.Scanner;
public class OtoKhach extends PhuongTien implements Thue {
	public double giaTri;
	public int viTri;

	public OtoKhach(String maPhuongTien, String trangThai, String tinhTrangBaoTri, int ngaySanXuat, int ngaySuDung,
			double giaTri, int viTri) {
		super(maPhuongTien, trangThai, tinhTrangBaoTri, ngaySanXuat, ngaySuDung);
		this.giaTri = giaTri;
		this.viTri = viTri;
	}

	public OtoKhach() {

	}

	public double getGiaTri() {
		return giaTri;
	}

	public int getViTri() {
		return viTri;
	}

	public void setGiaTri(double giaTri) {
		this.giaTri = giaTri;
	}

	public void setViTri(int viTri) {
		this.viTri = viTri;
	}

	public void nhapOtoKhach() {
		Scanner sc = new Scanner(System.in);
		super.nhapThongTin();
		System.out.printf("Nhap gia tri cua xe: ");
		giaTri = sc.nextDouble();
		System.out.printf("Nhap so cho ngoi: ");
		viTri = sc.nextInt();
	}

	@Override
	public double tinhThue() {
		if (viTri >= 5) {
			return this.giaTri * 0.3f + this.giaTri * 0.1f + this.giaTri * 0.2f;
		} else {
			return this.giaTri * 0.5f + this.giaTri * 0.1f + this.giaTri * 0.2f;
		}
	}

	@Override
	public String toString() {
		return "OtoKhach [maPhuongTien=" + maPhuongTien + ", trangThai=" + trangThai + ", tinhTrangBaoTri="
				+ tinhTrangBaoTri + ", ngaySanXuat=" + ngaySanXuat + ", ngaySuDung=" + ngaySuDung + ", giaTri=" + giaTri
				+ ", viTri=" + viTri + ", Thue=" + tinhThue() + "]";
	}

	public void xuatThongTin() {
		System.out.println(toString());
	}
}
