/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI14TH;
import java.util.Scanner;

public class PhuongTien {
	public String maPhuongTien, trangThai, tinhTrangBaoTri;
	public int ngaySanXuat, ngaySuDung;

	public PhuongTien(String maPhuongTien, String trangThai, String tinhTrangBaoTri, int ngaySanXuat, int ngaySuDung) {
		this.maPhuongTien = maPhuongTien;
		this.trangThai = trangThai;
		this.tinhTrangBaoTri = tinhTrangBaoTri;
		this.ngaySanXuat = ngaySanXuat;
		this.ngaySuDung = ngaySuDung;
	}

	public PhuongTien() {
	}

	public void nhapThongTin() {
		Scanner sc = new Scanner(System.in);
		System.out.printf("Nhap ma phuong tien: ");
		maPhuongTien = sc.nextLine();
		System.out.printf("Nhap trang thai: ");
		trangThai = sc.nextLine();
		System.out.printf("Nhap tinh trang bao tri: ");	
		trangThai = sc.nextLine();
		System.out.printf("Nhap ngay san xuat: ");
		ngaySanXuat= sc.nextInt();
		System.out.printf("Nhap ngay su dung: ");
		ngaySuDung= sc.nextInt();
	}

	@Override
	public String toString() {
		return "PhuongTien [maPhuongTien=" + maPhuongTien + ", trangThai=" + trangThai + ", tinhTrangBaoTri="
				+ tinhTrangBaoTri + ", ngaySanXuat=" + ngaySanXuat + ", ngaySuDung=" + ngaySuDung + "]";
	}
	
	public void xuatThongTin() {
		System.out.println(toString());
	}
}
