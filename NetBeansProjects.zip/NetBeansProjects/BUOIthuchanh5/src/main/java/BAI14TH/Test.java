/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI14TH;
public class Test {
public static void main(String[] args) {
	DanhSachXe ds = new DanhSachXe();
	ds.nhapDs();
	ds.xuatDs();
}
}