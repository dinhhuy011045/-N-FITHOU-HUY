/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI14TH;
public interface Thue {
	double tinhThue();
}
