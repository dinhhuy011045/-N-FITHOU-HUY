/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI14TH;
import java.util.Scanner;

public class XeDap extends PhuongTien implements Thue {
	public double giaTri;

	public XeDap(String maPhuongTien, String trangThai, String tinhTrangBaoTri, int ngaySanXuat, int ngaySuDung,
			double giaTri) {
		super(maPhuongTien, trangThai, tinhTrangBaoTri, ngaySanXuat, ngaySuDung);
		this.giaTri = giaTri;
	}

	public XeDap() {

	}

	public double getGiaTri() {
		return giaTri;
	}

	public void setGiaTri(double giaTri) {
		this.giaTri = giaTri;
	}

	public double tinhThue() {
		return 0;
	}

	public void nhapXeDap() {
		Scanner sc = new Scanner(System.in);
		super.nhapThongTin();
		System.out.printf("Nhap gia tri cua xe: ");
		giaTri = sc.nextDouble();
	}

	@Override
	public String toString() {
		return "XeDap [maPhuongTien=" + maPhuongTien + ", trangThai=" + trangThai + ", tinhTrangBaoTri="
				+ tinhTrangBaoTri + ", ngaySanXuat=" + ngaySanXuat + ", ngaySuDung=" + ngaySuDung + ", giaTri=" + giaTri
				+ ", Thue=" + tinhThue() + "]";
	}

	public void xuatThongTin() {
		System.out.println(toString());
	}
	
}
