/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI14TH;
import java.util.Scanner;
public class otoTai extends PhuongTien implements Thue {
	public double giaTri;

	public otoTai() {
	}
	public otoTai(String maPhuongTien, String trangThai, String tinhTrangBaoTri, int ngaySanXuat, int ngaySuDung,
			double giaTri) {
		super(maPhuongTien, trangThai, tinhTrangBaoTri, ngaySanXuat, ngaySuDung);
		this.giaTri = giaTri;
	}

	public double getGiaTri() {
		return giaTri;
	}

	public void setGiaTri(double giaTri) {
		this.giaTri = giaTri;
	}

	public double tinhThue() {
		return this.giaTri * 0.1f + this.giaTri * 0.02;
	}

	public void nhapXetai() {
		Scanner sc = new Scanner(System.in);
		super.nhapThongTin();
		System.out.printf("Nhap gia tri cua xe: ");
		giaTri = sc.nextDouble();
	}
	@Override
	public String toString() {
		return "otoTai [maPhuongTien=" + maPhuongTien + ", trangThai=" + trangThai + ", tinhTrangBaoTri="
				+ tinhTrangBaoTri + ", ngaySanXuat=" + ngaySanXuat + ", ngaySuDung=" + ngaySuDung + ", giaTri=" + giaTri
				+ ", Thue=" + tinhThue() + "]";
	}
	
	public void xuatThongTin() {
		System.out.println(toString());
	}
	
}
