/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI15TH;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class DanhSachHocSinh {
	private ArrayList<HocSinh> listHocSinh = new ArrayList<>();

	public void nhapDS() {
		Scanner sc = new Scanner(System.in);
		int soLuong;
		System.out.print("Nhap so luong hoc sinh muon nhap: ");
		soLuong = sc.nextInt();
		for (int i = 0; i < soLuong; i++) {
			HocSinh hs = new HocSinh();
			hs.nhapHocSinh();
			listHocSinh.add(hs);
		}
	}

	public void xuatDS() {
		System.out.println("HoTen\tNamSinh\t GioiTinh\tTenLop");
		for (HocSinh hocSinh : listHocSinh) {
			System.out.println(hocSinh.gioithieu());
		}
	}

	public void timKiem() {
		Scanner sc = new Scanner(System.in);
		int namSinh2;
		System.out.print("Nhap nam sinh can kiem: ");
		namSinh2 = sc.nextInt();
		System.out.println("HoTen\tNamSinh\t GioiTinh\tTenLop");
		for (HocSinh hocSinh : listHocSinh) {
			if (namSinh2 == hocSinh.getNamSinh()) {
				System.out.println(hocSinh.gioithieu());
			}
		}
	}

	public void ghiFile() {
	
		try {
			FileWriter fw = new FileWriter("input.txt");
			BufferedWriter bw = new BufferedWriter(fw);
			for (HocSinh hocSinh : listHocSinh) {
				bw.write(hocSinh.gioithieu());
				bw.newLine();
			}
			bw.close();
			fw.close();
			System.out.println("Luu file thanh cong!!!!!!!!!!!!!");
		} catch (Exception e) {
			System.out.println("Error");
		}
	}

	public void docFile() {
		System.out.println("HoTen\tNamSinh\t GioiTinh\tTenLop");
		try {
			FileReader fr = new FileReader("input.txt");
			try (BufferedReader br = new BufferedReader(fr)) {
				String line = "";
				while (true) {
					if (line == null) {
						break;
					} else {
						line = br.readLine();
						System.out.println(line);
					}
				}
			}
		} catch (Exception e) {
			System.out.println("Error");
		}
	}

}
