/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI15TH;
import java.util.Scanner;

public class HocSinh extends Nguoi implements IHoatDong {
	private String tenLop;

	public HocSinh() {
	}

	public HocSinh(String tenLop) {
		this.tenLop = tenLop;
	}

	public String getTenLop() {
		return tenLop;
	}

	public void setTenLop(String tenLop) {
		this.tenLop = tenLop;
	}

	public void nhapHocSinh() {
		super.nhap();
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhap ten lop: ");
		tenLop = sc.nextLine();
	}

	@Override
	public String gioithieu() {
		return getHoTen() + "\t" + getNamSinh() + "\t " + isGioiTinh() + "\t\t" + getTenLop();
	}
}
