/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI15TH;
public interface IHoatDong {
	String gioithieu();
}
