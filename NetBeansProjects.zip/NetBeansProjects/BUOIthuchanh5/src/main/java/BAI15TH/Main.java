/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI15TH;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		DanhSachHocSinh ds = new DanhSachHocSinh();
		Scanner sc = new Scanner(System.in);
		int chon;
		System.out.println("-------- Menu --------");
		System.out.println("1. Nhap danh sach ");
		System.out.println("2. Xuat danh sach");
		System.out.println("3. Tim kiem");
		System.out.println("4. Luu file");
		System.out.println("5. Doc file");
		System.out.println("0. Thoat");
		do {
			System.out.print("Moi chon: ");
			chon = sc.nextInt();
			switch (chon) {
			case 1:
				ds.nhapDS();
				break;
			case 2:
				ds.xuatDS();
				break;
			case 3:
				ds.timKiem();
				break;
			case 4:
				ds.ghiFile();
				break;
			case 5:
				ds.docFile();
				break;
                        }
		} while (chon != 0);

	}
}
