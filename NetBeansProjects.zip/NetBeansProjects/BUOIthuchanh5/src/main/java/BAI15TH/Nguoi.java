/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI15TH;
import java.util.Scanner;
public class Nguoi {
	private String hoTen;
	private int namSinh;
	private boolean gioiTinh;
	public Nguoi() {
	}
	public Nguoi(String hoTen, int namSinh) {
		this.hoTen = hoTen;
		this.namSinh = namSinh;
	}
	public String getHoTen() {
		return hoTen;
	}

	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}

	public int getNamSinh() {
		return namSinh;
	}

	public void setNamSinh(int namSinh) {
		this.namSinh = namSinh;
	}

	public boolean isGioiTinh() {
		return gioiTinh;
	}

	public void setGioiTinh(boolean gioiTinh) {
		this.gioiTinh = gioiTinh;
	}

	public void nhap() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhap ho ten: ");
		hoTen = sc.nextLine();
		System.out.print("Nam sinh: ");
		namSinh = sc.nextInt();
		System.out.print("Gioi tinh (Nu = true, Nam = false): ");
		gioiTinh = sc.nextBoolean();
	}

	public void xuat() {
		System.out.printf("%s%10d%10b", hoTen, namSinh, gioiTinh);
	}
}
