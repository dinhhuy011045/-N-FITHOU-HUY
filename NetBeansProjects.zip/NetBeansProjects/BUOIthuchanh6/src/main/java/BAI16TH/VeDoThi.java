/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI16TH;
import java.awt.*;
import java.awt.event.*;
public class VeDoThi extends Frame implements ActionListener{
    Label lb1 = new Label("Red:");
    Label lb2 = new Label("Blue:");
    Label lb3 = new Label("Green:");        
    Label lb4 = new Label("Yellow:");
    TextField txtRed = new TextField("60",5);
    TextField txtBlue = new TextField("80",5);
    TextField txtGreen = new TextField("90",5);
    TextField txtYellow = new TextField("50",5);
    Button btnDraw = new Button("Draw");
    int rr,bb,gg,yy;
public VeDoThi(){
    setLayout(new FlowLayout());
    btnDraw.addActionListener(this);
    add(lb1);           add(txtRed);
    add(lb2);           add(txtBlue);
    add(lb3);           add(txtGreen);
    add(lb4);           add(txtYellow);
    add(btnDraw);         
    rr= Integer.parseInt(txtRed.getText());
    bb= Integer.parseInt(txtBlue.getText());
    gg= Integer.parseInt(txtGreen.getText());
    yy= Integer.parseInt(txtYellow.getText());
}
public void paint(Graphics g){
    g.drawLine(50, 50, 50, 250);
    g.drawLine(50, 250, 350, 250);
    g.setColor(Color.RED);
    g.fillRect(80, 250-rr,30, rr);
    g.drawString(String.valueOf(rr), 80, 250-rr);
    g.setColor(Color.BLUE);
    g.fillRect(140, 250-bb,30,bb);
    g.drawString(String.valueOf(bb), 140, 250-bb);
    g.setColor(Color.GREEN);
    g.fillRect(200, 250-gg,30, gg);
    g.drawString(String.valueOf(gg), 200, 250-gg);
    g.setColor(Color.YELLOW);
    g.fillRect(260, 250-yy,30, yy);
    g.drawString(String.valueOf(yy), 260, 250-yy);
}
public void actionPerformed(ActionEvent e){
    rr= Integer.parseInt(txtRed.getText());
    bb= Integer.parseInt(txtBlue.getText());
    gg= Integer.parseInt(txtGreen.getText());
    yy= Integer.parseInt(txtYellow.getText());
    if(e.getSource()==btnDraw);
    repaint();  
   }
    public static void main(String[] args) {
        VeDoThi t = new VeDoThi();
        t.setVisible(true);
        t.setSize(1000, 900);
    }
}
