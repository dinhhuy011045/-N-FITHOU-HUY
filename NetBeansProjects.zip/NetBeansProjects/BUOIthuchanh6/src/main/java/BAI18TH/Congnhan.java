/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI18TH;
import java.util.ArrayList;
import java.util.Scanner;
public class Congnhan extends Connguoi implements PhuCap{
 private String maCN;

    public Congnhan(){}
    public Congnhan(String maCN) {
        this.maCN = maCN;
    }
public double PhuCap(){
    return Sonamcongtac*0.3f*(450000*2.34);
}
public void nhap(){
    super.nhap();
    Scanner sc = new Scanner(System.in);
    System.out.println("NHAP MA CONG NHAN:");
    maCN=sc.nextLine();  
    }

public void xuat(){       
    super.xuat();
    System.out.println("MA CONG NHAN:"+maCN);
    System.out.println("SO PHU CAP="+PhuCap());
}
}

    
    

    


    

