/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI18TH;
import java.util.Scanner;
public class Connguoi {
    private String hoTen;
    private String gioiTinh;
    private int namSinh;
    public float Sonamcongtac;
    public Connguoi(){}
    public Connguoi(String hoTen, String gioiTinh, int namSinh, int Sonamcongtac) {
        this.hoTen = hoTen;
        this.gioiTinh = gioiTinh;
        this.namSinh = namSinh;
        this.Sonamcongtac = Sonamcongtac;
    }

    
public void nhap(){
    Scanner sc =  new Scanner(System.in);
    System.out.println("NHAP HO TEN:");
    hoTen=sc.nextLine();
    System.out.println("NHAP GIOI TINH:");
    gioiTinh=sc.nextLine();
    System.out.println("NHAP NAM SINH:");
    namSinh=sc.nextInt();
    System.out.println("NHAP SO NAM CONG TAC:");
    Sonamcongtac=sc.nextInt();
}
public void xuat(){
    System.out.println("HO TEN:"+hoTen);
    System.out.println("GIOI TINH:"+gioiTinh);
    System.out.println("NAM SINH:"+namSinh);
    System.out.println("SO NAM CONG TAC:"+Sonamcongtac);
}

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(String gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public int getNamSinh() {
        return namSinh;
    }

    public void setNamSinh(int namSinh) {
        this.namSinh = namSinh;
    }

    public float getSonamcongtac() {
        return Sonamcongtac;
    }

    public void setSonamcongtac(int Sonamcongtac) {
        this.Sonamcongtac = Sonamcongtac;
    }


    
    
}
