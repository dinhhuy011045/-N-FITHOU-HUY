/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI18TH;
import java.util.Scanner;
        
public class Dienvien extends Connguoi implements PhuCap{
    private String MaDV;
public Dienvien(){}
public double PhuCap(){
    return 0.1f*(450000*3.2f)*Sonamcongtac;
}
public void nhap(){
    super.nhap();
    Scanner sc = new Scanner(System.in);
    System.out.println("NHAP MA CONG NHAN:");
    MaDV=sc.nextLine();   
}
public void xuat(){
    super.xuat();
    System.out.println("MA DIEN VIEN:"+MaDV);
    System.out.println("SO PHU CAP="+PhuCap());
}
    
}
