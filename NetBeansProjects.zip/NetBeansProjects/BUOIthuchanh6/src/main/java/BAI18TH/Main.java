/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI18TH;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void MENU(){
        System.out.println("\n");
        System.out.println("===========MENU===========");
        System.out.println("1.CONG NHAN");
        System.out.println("2.KI SU");
        System.out.println("3.DIEN VIEN");
        System.out.println("4.HIEN DANH SACH");
        System.out.println("0.THOAT");  
    }
public static void main(String[] args) {
        ArrayList<Connguoi> lstConnguoi = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        int chon;       
        do{
            MENU();
        System.out.println("MOI BAN CHON:");
        chon=sc.nextInt();
            switch(chon){
                case 1:
                    Scanner scu = new Scanner(System.in);
                    int n;
                    System.out.println("NHAP DANH SACH CONG NHAN:");
                    n=scu.nextInt();
                    for (int i = 0; i < n; i++) { 
                    System.out.println("\n");
                    Congnhan cnh = new Congnhan();
                    cnh.nhap();
                    lstConnguoi.add(cnh);}
                    break;
                case 2:   
                    Scanner scut = new Scanner(System.in);
                    int m;
                    System.out.println("NHAP DANH SACH DIEN VIEN:");
                    m=scut.nextInt();
                    for (int i = 0; i < m; i++) { 
                    System.out.println("\n");
                    Dienvien dv = new Dienvien();
                    dv.nhap();
                    lstConnguoi.add(dv); }             
                    break;
                case 3:       
                    Scanner scuy = new Scanner(System.in);
                    int b;
                    System.out.println("NHAP DANH SACH KY SU:");
                    b=scuy.nextInt();
                    for (int i = 0; i < b; i++) { 
                    System.out.println("\n");
                    Kisu ks = new Kisu();
                    ks.nhap();                            
                    lstConnguoi.add(ks);}
                    
                    break;
                case 4:
                  
                    for (Connguoi connguoi : lstConnguoi) {
                       System.out.println("\n");
                       connguoi.xuat();
                       
                    }
                    break;
                case 0:
                    System.exit(chon);
                default:
                    System.out.println("HAY NHAP LAI");
            }
        }while(chon!=0);
        }
            
        
}
