/*
 Ho Ten:Nguyễn Đình Huy
 Mã Lớp:S511TH2022.018
*/
package BAI18TH;
public interface PhuCap {
    double PhuCap();
}
