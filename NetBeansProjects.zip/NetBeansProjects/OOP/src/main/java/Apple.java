
import java.awt.Point;

public class Apple {
  private int x;
  private int y;

  public Apple(int x, int y) {
    this.x = x;
    this.y = y;
  }

  public void setLocation(int x, int y) {
    this.x = x;
    this.y = y;
  }

  public Point getLocation() {
    return new Point(x, y);
  }
}


