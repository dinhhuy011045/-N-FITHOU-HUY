package BAI10TH;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;
public class Bai10 {
    public static void menu(){
         System.out.println("""
                           +---------------------Menu---------------------+
                           |1.Nhap danh sach cac tu lanh                  |
                           |2.In danh sach cac tu lanh                    |
                           |3.Liet ke danh sach tu lanh theo hang         |
                           |4.Tong tien cac tu lanh                       |
                           |5.In cac tu lanh co dung tich tren 200 lit    |
                           |6.Sắp xep theo thu tu giam dan cua so luong   |
                           |0.Exit                                        |
                           +----------------------------------------------+
                           """);
    }
    
    public static void main(String[] args) throws IOException, FileNotFoundException, ClassNotFoundException {
        DSTL a = new DSTL();
        Scanner sc = new Scanner(System.in);
        int chon;
        do{
            menu();
            System.out.print("Moi ban chon: ");
            chon = sc.nextInt();
            switch(chon){
                case 1:
                { a.NhapDSTL();break;}
                case 2: {
                    a.InDSTL();break;
                }
                case 3: {
                    a.lietKe();
                    break;
                }
                case 4: {
                    a.tongTien();
                    break;
                }
                case 5:{
                    a.TLTDT();
                    break;
                }
                case 6:{
                    a.sapXepGiamSoLg();
                    break;
                }
                case 7: {
                    a.ghi_file();
                    System.out.println("GHi FILE THANH CONG");
                    break;
                }
                case 8:{
                    a.doc_file();
                    System.out.println("DOC FILE THANH CONG");
                    break;
                }
                case 0:{
                    System.out.println("Nguyen");
                }
            }
        }while(chon != 0);
        
        
    }

}
