package BAI10TH;
import java.io.File;
import java.io.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.*;
import java.util.Comparator;
import java.util.Scanner;

public class DSTL {

    ArrayList<TULANH> dstl;

    public void NhapDSTL() {
        Scanner sc = new Scanner(System.in);
        int n;
        System.out.println("Nhap so tu lanh can quan ly: ");
        n = sc.nextInt();
        sc.nextLine();
        dstl = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            System.out.println("--------------" + (i + 1) + "--------------");
            TULANH tl = new TULANH();
            tl.Nhap();
            dstl.add(tl);
        }
    }

    public void InDSTL() {
        System.out.println("Danh sach tu lanh:");
        for (TULANH tl : dstl) {
            tl.Xuat();
            System.out.println();
        }
    }

    public void lietKe() {
        String tg;
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap hang san xuat: ");
        tg = sc.nextLine();
        for (TULANH tl : dstl) {
            if (tl.getHangSX().equals(tg)) {
                tl.Xuat();
                System.out.println();
            }
        }
    }

    public void tongTien() {
        double sum = 0;
        for (TULANH tl : dstl) {
            sum += tl.thanhTien();
        }
        System.out.println("Tong tien cac tu lanh co trong danh sach da dươc lap la: " + sum);
    }

    public void TLTDT() {
        System.out.println("Danh sach cac tu lanh co dung tich tren 200 lit: ");
        for (TULANH tl : dstl) {
            if (tl.getDungTich() > 200) {
                tl.Xuat();
                System.out.println();
            }
        }
    }

    public void sapXepGiamSoLg() {
        Collections.sort(dstl, new SortBySoLuong());
        for (TULANH tl : dstl) {
            tl.Xuat();
            System.out.println();
        }
    }

    public void doc_file()
            throws FileNotFoundException, IOException, ClassNotFoundException {
        File fname = new File("TULANH.dat");
        FileInputStream fin = new FileInputStream(fname);
        ObjectInputStream in = new ObjectInputStream(fin);
//        ArrayList<TULANH> dstl;
        dstl = (ArrayList<TULANH>) in.readObject();
        in.close();
        fin.close();

    }

    public void ghi_file()
            throws FileNotFoundException, IOException {
        File fname = new File("TULANH.dat");
        FileOutputStream fout = new FileOutputStream(fname);
        ObjectOutputStream out = new ObjectOutputStream(fout);
        out.writeObject(dstl);
        out.close();
        fout.close();

    }

}

