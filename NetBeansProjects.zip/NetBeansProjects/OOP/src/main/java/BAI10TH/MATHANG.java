package BAI10TH;
import java.io.Serializable;
import java.util.Scanner;

public class MATHANG implements Serializable{

    protected String tenHang, nuocSX;
    protected int maHang;

    public MATHANG(String tenHang, String nuocSX, int maHang) {
        this.tenHang = tenHang;
        this.nuocSX = nuocSX;
        this.maHang = maHang;
    }

    public MATHANG() {
    }

    public String getTenHang() {
        return tenHang;
    }

    public void setTenHang(String tenHang) {
        this.tenHang = tenHang;
    }

    public String getNuocSX() {
        return nuocSX;
    }

    public void setNuocSX(String nuocSX) {
        this.nuocSX = nuocSX;
    }

    public int getMaHang() {
        return maHang;
    }

    public void setMaHang(int maHang) {
        this.maHang = maHang;
    }

    @Override
    public String toString() {
        return "MATHANG{" + "tenHang=" + tenHang + ", nuocSX=" + nuocSX + ", maHang=" + maHang + '}';
    }

    public void Nhap() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap ten hang: ");
        tenHang = sc.nextLine();
        System.out.print("Nhap nuoc San Xuat: ");
        nuocSX = sc.nextLine();
        System.out.print("Nhap ma hang: ");
        maHang = sc.nextInt();

    }

    public void Xuat() {
        System.out.printf("%-20s", tenHang);
        System.out.printf("%-20d", maHang);
        System.out.printf("%-15s", nuocSX);
    }
}
