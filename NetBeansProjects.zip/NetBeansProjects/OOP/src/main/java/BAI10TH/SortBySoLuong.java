package BAI10TH;
import java.util.Comparator;

public class SortBySoLuong implements Comparator<TULANH> {

    @Override
    public int compare(TULANH o1, TULANH o2) {
        return o2.getSoLuong() - o1.getSoLuong();
    }

}
