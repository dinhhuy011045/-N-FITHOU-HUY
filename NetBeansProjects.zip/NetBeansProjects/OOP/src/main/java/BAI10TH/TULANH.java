package BAI10TH;
import java.io.Serializable;
import java.util.Scanner;

public class TULANH extends MATHANG {

    private String mauSac, hangSX;
    private int dungTich, soLuong;
    private float donGia;

    public TULANH(String mauSac, String hangSX, int dungTich, int soLuong, float donGia, String tenHang, String nuocSX, int maHang) {
        super(tenHang, nuocSX, maHang);
        this.mauSac = mauSac;
        this.hangSX = hangSX;
        this.dungTich = dungTich;
        this.soLuong = soLuong;
        this.donGia = donGia;
    }

    public TULANH() {
    }

    public String getMauSac() {
        return mauSac;
    }

    public void setMauSac(String mauSac) {
        this.mauSac = mauSac;
    }

    public String getHangSX() {
        return hangSX;
    }

    public void setHangSX(String hangSX) {
        this.hangSX = hangSX;
    }

    public int getDungTich() {
        return dungTich;
    }

    public void setDungTich(int dungTich) {
        this.dungTich = dungTich;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public float getDonGia() {
        return donGia;
    }

    public void setDonGia(float donGia) {
        this.donGia = donGia;
    }
    
    public void Nhap() {
        Scanner sc = new Scanner(System.in);
        super.Nhap();
        System.out.print("Nhap mau sac: ");
        mauSac = sc.nextLine();
        System.out.print("Nhap hang san xuat: ");
        hangSX = sc.nextLine();
        System.out.print("Nhap dung tich (dv lit): ");
        dungTich = sc.nextInt();
        System.out.print("Nhap so luong: ");
        soLuong = sc.nextInt();
        System.out.print("Nhap don gia (nghin dong): ");
        donGia = sc.nextFloat();

    }

    public void Xuat() {
        super.Xuat();
        System.out.printf("%-10s %-20s %-10d %-7d %-15f" , mauSac, hangSX, dungTich, soLuong, donGia);
       
    }
    
    public double thanhTien(){
        double thanhTien ;
        thanhTien = soLuong * donGia;
        return thanhTien;
    }
}
