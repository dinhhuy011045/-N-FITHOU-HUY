package BAI13TH;
import java.util.Scanner;
public class CANBO {
    private String HoTen;
    private String GioiTinh;
    public float hsl;
public CANBO(){}
    public CANBO(String HoTen, String GioiTinh) {
        this.HoTen = HoTen;
        this.GioiTinh = GioiTinh;
        this.hsl=hsl;
    }
public void NHAP(){
    Scanner sc = new Scanner(System.in);
    System.out.println("NHAP HO TEN:");
    HoTen=sc.nextLine();
    System.out.println("NHAP GIOI TINH");
    GioiTinh=sc.nextLine();
    System.out.println("NHAP HE SO LUONG");
    hsl=sc.nextFloat();
}
public void XUAT(){
    System.out.println("HO TEN:"+HoTen);
    System.out.println("GIOI TINH:"+GioiTinh);
    System.out.println("HE SO LUONG:"+hsl);
}  
    public float getHsl() {
        return hsl;
    }

    public void setHsl(float hsl) {
        this.hsl = hsl;
    }
}
