package BAI13TH;
import java.util.Scanner;
public class CHUYENVIEN extends CANBO implements TinhLuong{
    private String PhongBan;
public CHUYENVIEN(){}
    public CHUYENVIEN(String PhongBan) {
        this.PhongBan = PhongBan;
    }
public void NHAP(){
    super.NHAP();
    Scanner sc = new Scanner(System.in);
    System.out.println("NHAP PHONG BAN:");
    PhongBan=sc.nextLine();  
}
public void XUAT(){
    super.XUAT();
    System.out.println("TEN PHONG BAN:"+PhongBan);   
    System.out.println("LUONG:"+TinhLuong());
}
    @Override
    public float TinhLuong() {
        return this.hsl*1350000;
    }
}

