package BAI13TH;

import java.util.Scanner;

public class GIANGVIEN extends CANBO implements TinhLuong {
    private String Khoa;
public GIANGVIEN(){}
    public GIANGVIEN(String Khoa) {
        this.Khoa = Khoa;
    }

public void NHAP(){
    super.NHAP();
    Scanner sc = new Scanner(System.in);
    System.out.println("NHAP TEN KHOA:");
    Khoa=sc.nextLine();      
}
public void XUAT(){
    super.XUAT();
    System.out.println("TEN KHOA:"+Khoa);
    System.out.println("LUONG:"+TinhLuong());
}
public float TinhLuong(){
    return hsl*1350000+0.2f;
}    
}
