package BAI13TH;
import java.util.Scanner;
import java.util.ArrayList;
        
public class MAIN {
    public static void MENU(){
        System.out.println("===========MENU===========");
        System.out.println("1.NHAP DANH SACH CHUYEN VIEN.");
        System.out.println("2.NHAP DANH SACH GIANG VIEN.");
        System.out.println("3.NHAP DANH SACH  QUAN LY");
        System.out.println("4.XUAT DANH SACH.");
        System.out.println("0.THOAT CHUONG TRINH.");
    }
    public static void main(String[] args){ 
        ArrayList<CANBO> dscanbo=new ArrayList<CANBO>();
        int chon;
        do {
            MENU();
            Scanner sc = new Scanner(System.in);            
            System.out.println("MOI BAN CHON:");
            chon=sc.nextInt();
            switch (chon) {
                case 1:
                CHUYENVIEN cv = new CHUYENVIEN();                  
                cv.NHAP();
                dscanbo.add(cv);
                    break;
                case 2:
                GIANGVIEN gv = new GIANGVIEN();                    
                    gv.NHAP();
                    dscanbo.add(gv);
                    break;
                case 3:
                QUANLY ql = new QUANLY();                   
                    ql.NHAP();
                    dscanbo.add(ql);
                    break;
                case 4:
                    for (CANBO canbo:dscanbo) {
                        canbo.XUAT();
                                
                    }
                                           
                    break;
                case 0:
                    System.exit(chon);
                default:
                    System.out.println("HAY NHAP LAI");
            }
        }
        while (chon!=0) ;            
             
        }}
                    
                    
                
                    
                    
                    
          