package BAI13TH;
import java.util.Scanner;
public class QUANLY extends CANBO implements TinhLuong{
   private float PhuCap;
    public QUANLY() {}
    public QUANLY(float PhuCap) {
        this.PhuCap = PhuCap;
    }
    public float getPhuCap() {
        return PhuCap;
    }
    public void setPhuCap(float PhuCap) {
        this.PhuCap = PhuCap;
    }

    public float getHsl() {
        return hsl;
    }

    public void setHsl(float hsl) {
        this.hsl = hsl;
    }
    
public void NHAP(){
    super.NHAP();
    Scanner sc = new Scanner(System.in);
    System.out.println("NHAP HE SO PHU CAP");
    PhuCap=sc.nextFloat();
}  
public void XUAT(){
    super.XUAT();
    System.out.println("HE SO PHU CAP:"+PhuCap);
    System.out.println("LUONG:"+TinhLuong());
}
public float TinhLuong(){
    return (hsl+PhuCap)*1350000;
            }
   

}
