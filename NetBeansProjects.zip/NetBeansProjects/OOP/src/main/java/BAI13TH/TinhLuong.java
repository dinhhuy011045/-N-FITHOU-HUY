package BAI13TH;
public interface TinhLuong{
   float TinhLuong();
}
