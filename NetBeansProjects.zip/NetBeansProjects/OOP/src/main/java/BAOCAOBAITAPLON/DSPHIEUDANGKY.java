package BAOCAOBAITAPLON;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
public class DSPHIEUDANGKY implements Serializable {
ArrayList<PHIEUDANGKY> dsphieudangky;
//1.nhap danh sach
public void nhapdspdk() {
	Scanner sc=new Scanner(System.in);	
	int n;
	do {
	System.out.println("Nhap so luong phieu :");
	n=sc.nextInt();
	if(n<=0) {
		System.out.println("So luong phieu phai lon hon 0 ! Xin moi nhap lai ");		
	}}
	while(n<=0);
	dsphieudangky=new ArrayList<PHIEUDANGKY>(n);
	for(int i=0;i<n ;i++) {
		System.out.println("\n\t\t NHAP PHIEU DANG KY THU "+(i+1)+"\n");
		PHIEUDANGKY pdk= new PHIEUDANGKY();
		pdk.nhap();
		dsphieudangky.add(pdk);		
	}
}
//2.xuat danh sach
public void xuatpdk() {
	System.out.println("\n\t\t XUAT DANH SACH PHIEU DANG KY \n");	
	for(PHIEUDANGKY pdk:dsphieudangky) {
            System.out.println("============================");
		pdk.xuat();
	}
}
 //3.tao luu file
public void ghifile() throws IOException {
	File fname=new File("dsphieudangky.dat");	
	try {
		FileOutputStream fout=new FileOutputStream(fname) ;
		ObjectOutputStream out=new ObjectOutputStream(fout);
		out.writeObject(dsphieudangky);
		out.close();
		fout.close();
	}
	catch(FileNotFoundException e){
		e.printStackTrace();
   	  	System.out.println("\nGhi File that bai!"+e.toString());		
	}
	catch(IOException e) {
		e.printStackTrace();
	}
	System.out.println("Ghi file thanh cong !");
}

//4.Tim kiem thong tin theo ma phieu dang ky
public void timkiemtheopdk(String mapdk) {
	for(PHIEUDANGKY pdk:dsphieudangky) {
		if(pdk.getMaphieu().equals(mapdk)==true) {
			pdk.xuat();                 
                }
	}
}
//5.xoa thong tin theo ma phieu 
public void xoatheoma(String mapdk)
{
	boolean kiemtra=false;
	for(PHIEUDANGKY pdk:dsphieudangky) {
            System.out.println("\n");
	    if(pdk.getMaphieu().equals(mapdk)) {
			dsphieudangky.remove(pdk) ;
			kiemtra=true;
			break;
		}}
	    if(kiemtra==true) {
		System.out.println("xoa thanh cong!");
	    }
	    else{
		System.out.println("\nxoa khong thanh cong!\n");
		}		
}
//6.thay doi thong tin thi sinh theo ma phieu dang ky
public void thaydoi(String mapdk) {
	for(PHIEUDANGKY pdk:dsphieudangky) {
		if(pdk.getMaphieu().equals(mapdk)==true) {
			THISINH ts=new THISINH();
			ts.nhap();
			pdk.setTsinh(ts);
		}
	}
}
//7.sap xep phieu dang ky
public void sapxeptheodiemgiamdan() {
	System.out.println("\n\t\t DANH SACH PHIEU DANG KY SAU KHI SAP XEP \n");
	 Collections.sort(dsphieudangky, new Comparator<PHIEUDANGKY>() {
           @Override
           public int compare(PHIEUDANGKY pdk1, PHIEUDANGKY pdk2) {
               return (pdk1.getMaphieu().compareTo(pdk2.getMaphieu()));
           }
       });	
	 int i=1;
		for(PHIEUDANGKY pdk : dsphieudangky) {
			System.out.println("\n\t\t THONG TIN PHIEU DANG KY THU "+(i++)+" LA :\n ");
			pdk.xuat();
		}	
}
//8.tim max diem 
public float timmaxdiem() {
	float max=0;
	for(PHIEUDANGKY pdk:dsphieudangky) {
		if(pdk.tinhdiem()>max) {
			max=pdk.tinhdiem();
		}
	}
	return max;
}
//9.in thong tin thi sinh do hoac truot
public void inthisinhdohoactruot() {
	String mapdk;
	Scanner sc=new Scanner(System.in);
	System.out.println("nhap ma phieu dang ky can kiem tra :");
	mapdk=sc.nextLine();
	int dem=0;	
	for(PHIEUDANGKY pdk:dsphieudangky) {
		if(pdk.getMaphieu().equals(mapdk)==true) {
		  if( pdk.xettrungtuyen()==true) {
			 dem=1;
		  }
		}
	}
	if(dem>0) {
		System.out.println("Thi sinh da DO  ");
	}
	else {
		System.out.println("Thi sinh da TRUOT  ");
	}}
//10.doc file
public void docfile() throws Exception, ClassNotFoundException {
	try {
		FileInputStream fin= new FileInputStream("dsphieudangky.dat");
		ObjectInputStream in=new ObjectInputStream(fin);
		dsphieudangky=(ArrayList)in.readObject();
		in.close();
		fin.close();
	} catch (FileNotFoundException e) {
		System.out.println("dọc file that bai !"+e.toString());
		e.printStackTrace();
	}
	catch(IOException e) {
		e.printStackTrace();
	}
	System.out.println("Doc file thanh cong !");		
}
public void kiemtrangaysinhthissinh(){
        int ngaysinh;
        Scanner sc=new Scanner(System.in);
        do{
	System.out.println("nhap ngay sinh thi sinh can kiem tra :");
	ngaysinh=sc.nextInt();
        if(ngaysinh<=0||ngaysinh>=32){
            System.out.println("NHAP SAI NGAY SINH THI SINH HAY NHAP LAI");
        }
        else{
            System.out.println("ngay sinh vua nhap la:"+ngaysinh);
        }
        }
        while(ngaysinh<=0 || ngaysinh>=32);
        
    
}}
