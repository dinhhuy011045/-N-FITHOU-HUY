package BAOCAOBAITAPLON;

import java.io.Serializable;
import java.util.Scanner;
public class NGUOI implements Serializable{
protected String hoten;
protected String gioitinh;
public NGUOI() {
}
public NGUOI(String hoten, String gioitinh) {
	this.hoten = hoten;
	this.gioitinh = gioitinh;
}
public void nhap() {
	Scanner sc=new Scanner(System.in);
	System.out.println("nhap ho ten :");
	hoten=sc.nextLine();
	System.out.println("nhap gioi tinh :");
	gioitinh=sc.nextLine();	
}
public void xuat() {
	System.out.println("-Ho ten :"+hoten+"  "+"||\tGioi tinh :"+gioitinh);  
}
public String getHoten() {
	return hoten;
}
public void setHoten(String hoten) {
	this.hoten = hoten;
}
public String getGioitinh() {
	return gioitinh;
}
public void setGioitinh(String gioitinh) {
	this.gioitinh = gioitinh;
}
@Override
public String toString() {
	return "NGUOI [hoten=" + hoten + ", gioitinh=" + gioitinh + "]";
}
}


