package BAOCAOBAITAPLON;
import java.io.IOException;
import java.util.Scanner;
public class test {
public static void main(String[] args) throws IOException, ClassNotFoundException, Exception {
	Scanner sc=new Scanner(System.in);
	DSPHIEUDANGKY dspdk=new DSPHIEUDANGKY();
	int luachon;
	do {
		System.out.println("\n============================= QUAN LY TUYEN SINH DAI HOC ============================= \n");
		System.out.println("1.nhap thong tin danh sach phieu dang ky");
		System.out.println("2.xuat thong tin danh sach phieu dang ky");
		System.out.println("3.tao va luu file dsphieudangky.dat");
		System.out.println("4.Tim kiem thong tin theo ma phieu dang ky ");
		System.out.println("5.xoa thong tin theo ma phieu dang ky");
		System.out.println("6.thay doi thong tin thi sinh theo ma phieu dang ky ");
		System.out.println("7.sap xep danh sach phieu dang ky theo ma phieu");
		System.out.println("8.tim max diem");
		System.out.println("9.in thong tin thi sinh do hoac truot");
		System.out.println("10.Doc file dsphieudangky.dat");
                System.out.println("11.Kiem tra so luong  can bo");
		System.out.println("0.ket thuc.");
		do {
		System.out.println("- Moi ban nhap lua chon :");
		luachon=sc.nextInt();
		if(luachon<0||luachon>11) {
			System.out.println("\t\tNhap sai xin moi nhap lai !\n");
		}}
		while(luachon<0||luachon>11);
		if(luachon==1) {
			dspdk.nhapdspdk();
		}
		else if(luachon==2) {
			dspdk.xuatpdk();
		}
        else if(luachon==3) {
			dspdk.ghifile();
		}
        else if(luachon==4) {
        	String mapdk;
        	sc.nextLine();
	       	System.out.println("Nhap ma phieu dang ky can tim kiem :");
                mapdk=sc.nextLine();
                System.out.println("Phieu dang ky can tim kiem la:");
                dspdk.timkiemtheopdk(mapdk);
        }
        else if(luachon==5) {
        	sc.nextLine();
	        String mapdk;
	    	System.out.println("Nhap ma phieu dang ky  can xoa :");
                mapdk=sc.nextLine();
	        dspdk.xoatheoma(mapdk);
	        System.out.println("\n\t\t DANH SACH PHIEU DANG KY SAU KHI XOA \n");
	        dspdk.xuatpdk();	         
        }
        else if(luachon==6) {
        	sc.nextLine();
        	String mapdk;
	        System.out.println("nhap ma phieu thi sinh can thay doi thong tin :");
	        mapdk=sc.nextLine();
	        dspdk.thaydoi(mapdk);
        }
        else if(luachon==7) {
        	dspdk.sapxeptheodiemgiamdan();
	
        }
        else if(luachon==8) {
                 
        	System.out.println("Diem MAX cua thi sinh can tim la:"+dspdk.timmaxdiem());
        }
        else if(luachon==9) {
        	dspdk.inthisinhdohoactruot();
        }
        else if(luachon==10) {
        	dspdk.docfile();
        	dspdk.xuatpdk();
        }
        else if(luachon==11){
               dspdk.kiemtrangaysinhthissinh();
        }
            
        
        }
	while(luachon!=0);
	sc.nextLine();
        System.out.println("<======End Of Programming======>");
}
}

