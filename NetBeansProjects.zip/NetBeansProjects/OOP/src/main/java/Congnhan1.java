
import java.util.Scanner;
public class Congnhan1 {
	private float hsl;
	private String hovaten;
	public Congnhan1() {
		this.hsl = hsl;
		this.hovaten = hovaten;
	}
	Scanner sc=new Scanner(System.in);
	public float getHsl() {
		return hsl;
	}
	public void setHsl(float hsl) {
		this.hsl = hsl;
	}
	public String getHovaten() {
		return hovaten;
	}
	public void setHovaten(String hovaten) {
		this.hovaten = hovaten;
	}
	public float luong() {
		return 1150*this.hsl;
	}
	public void nhap() {
		System.out.println("nhap ho va ten: ");
		hovaten=sc.nextLine();
		System.out.println("nhap he so luong: ");
		hsl=sc.nextFloat();
		sc.nextLine();
	}
	public void hien(float phucap) {
		System.out.println("ho va ten: "+hovaten);
		System.out.println("he so luong: "+hsl);
		System.out.println("luong chua gom phu cap: "+(hsl*1150));
		System.out.println("luong gom phu cap: "+(hsl*1150*(1+phucap)));
		double a=(hsl*1150)*(1+phucap)-(hsl*1150);
		System.out.println("so tien chenh lech do chi tra phu cap la: "+a);
	}
}  

