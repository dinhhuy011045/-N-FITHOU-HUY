
import java.util.Scanner;
import java.util.ArrayList;
public class Congnhan2{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		ArrayList<Congnhan1> dscn=new ArrayList<>();
		System.out.println("nhap so cong nhan can nhap danh sach: ");
		int n=sc.nextInt();
		float phucap = 0;
		if(n>0&&n<=20) {
			for(int i=0;i<n;i++) {
				Congnhan1 cn=new Congnhan1();
				System.out.println("nhap thong tin cho cong nhan thu "+(i+1)+": ");
				cn.nhap();
				System.out.println("nhap tien phu cap: ");
				phucap=sc.nextFloat();
				sc.nextLine();
				dscn.add(cn);
				System.out.println();
			}   
			System.out.println("thong tin cac cong nhan vua nhap la: ");
			System.out.println("");
			int i=1;
			for(Congnhan1 cn : dscn){
				System.out.println("thong tin sinh vien thu "+i+": ");
				cn.hien(phucap);
				System.out.println();
				i++;
			}
		}
		else {
			System.out.println("nhap so cong nhan vuot gioi han , moi nhap lai ");
		}
	}
}
