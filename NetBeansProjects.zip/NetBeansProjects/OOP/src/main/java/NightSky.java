import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class NightSky extends JPanel implements ActionListener {
    private ArrayList<Point> stars;
    private Timer timer;

    public NightSky() {
        stars = new ArrayList<>();
        for (int i = 0; i < 50; i++) {
            int x = (int) (Math.random() * 400);
            int y = (int) (Math.random() * 400);
            stars.add(new Point(x, y));
        }
        timer = new Timer(100, this);
        timer.start();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        this.setBackground(Color.BLACK);

        g.setColor(Color.WHITE);
        for (Point star : stars) {
            g.fillOval(star.x, star.y, 3, 3);
        }
    }

    public void actionPerformed(ActionEvent e) {
        for (Point star : stars) {
            star.x += (int) (Math.random() * 5 - 2);
            star.y += (int) (Math.random() * 5 - 2);
        }
        repaint();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Night Sky");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);
        NightSky panel = new NightSky();
        frame.add(panel);
        frame.setVisible(true);
    }
}